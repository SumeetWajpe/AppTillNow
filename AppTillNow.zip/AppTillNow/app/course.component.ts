import { Component,Input} from '@angular/core';

@Component({
   selector:'course',
   templateUrl:'./app/course.component.html',
   styles:[`
   .Highlight{
       background-color:lightgreen;
       margin:10px;
       padding:10px;
   }
   .Bordered{
    border:2px solid red;
    border-radius:10px;
   }
   `]
//    template:`
//    <h1>{{courseDetails.name}}</h1>
//    <!--<input type="text" [value]="courseDetails.name"
//    (input)="CalledOnChangeOftext($event)"  
//    /> <br/>-->

// <!--
//     <input type="text" [(ngModel)]="courseDetails.name" /> -->


//    <img src="{{courseDetails.imageUrl}}" height="200px"  /> 
//    <img [src]="courseDetails.imageUrl" height="200px"  /> <br/>
//    <b> Duration: </b> {{courseDetails.duration}} <br/>

//    Is This course Free ? 
//    <input type="checkbox" [(ngModel)]="courseDetails.isFree" />

//     <div *ngIf="!courseDetails.isFree">
//    <b> Price: </b> {{courseDetails.price}} 
//    </div>
//    <br/>
//    <b> Trainer: </b> {{courseDetails.trainer}} <br/> 
//    <input type="button" value="Is Success ?"
//     [style.backgroundColor]="isSuccess ? 'green' : 'red' " 
//     (click)="CalledOnClick()" />
//    `    
})
export class CourseComponent{
//    @Input('cname') coursename:string = "Angular 2.0";
isSuccess:boolean=true;

    styleToBeApplied={backgroundColor:'lightblue'};

    classTobeApplied="Highlight Bordered";

    courseDetails={
        name:'Angular',
        duration:'2 Days',
        price:5000,
        trainer:'Mr. Sumeet',
        imageUrl:'https://qph.ec.quoracdn.net/main-qimg-30ea9a9396bde99772ea0bfd1c20b15a',
        isFree:true,
        topics:[
            {name:'Angular Basics',rating:3,duration:'1 Hour'},
            {name:'Angular Pipes',rating:4,duration:'1 Hour'},
            {name:'Angular Services',rating:2.5,duration:'2 Hours'},
            {name:'Angular Bindings',rating:4,duration:'1 Hour'}           
        ]
    };

    CalledOnClick(){
        this.courseDetails.name = "Angular 2.0";
        this.isSuccess = false;
    }

    CalledOnChangeOftext(evt:any){        
        this.courseDetails.name = evt.target.value;
    }
}