import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  // template: `
  // <course cname="ReactJS"></course>
  // <course cname="NodeJS"></course>
  // <course></course> 
  
  // `,
  template: `  
  <course></course>   
  `
})
export class AppComponent  { name = 'Angular'; }

