"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var CourseComponent = (function () {
    function CourseComponent() {
        //    @Input('cname') coursename:string = "Angular 2.0";
        this.isSuccess = true;
        this.styleToBeApplied = { backgroundColor: 'lightblue' };
        this.classTobeApplied = "Highlight Bordered";
        this.courseDetails = {
            name: 'Angular',
            duration: '2 Days',
            price: 5000,
            trainer: 'Mr. Sumeet',
            imageUrl: 'https://qph.ec.quoracdn.net/main-qimg-30ea9a9396bde99772ea0bfd1c20b15a',
            isFree: true,
            topics: [
                { name: 'Angular Basics', rating: 3, duration: '1 Hour' },
                { name: 'Angular Pipes', rating: 4, duration: '1 Hour' },
                { name: 'Angular Services', rating: 2.5, duration: '2 Hours' },
                { name: 'Angular Bindings', rating: 4, duration: '1 Hour' }
            ]
        };
    }
    CourseComponent.prototype.CalledOnClick = function () {
        this.courseDetails.name = "Angular 2.0";
        this.isSuccess = false;
    };
    CourseComponent.prototype.CalledOnChangeOftext = function (evt) {
        this.courseDetails.name = evt.target.value;
    };
    return CourseComponent;
}());
CourseComponent = __decorate([
    core_1.Component({
        selector: 'course',
        templateUrl: './app/course.component.html',
        styles: ["\n   .Highlight{\n       background-color:lightgreen;\n       margin:10px;\n       padding:10px;\n   }\n   .Bordered{\n    border:2px solid red;\n    border-radius:10px;\n   }\n   "]
        //    template:`
        //    <h1>{{courseDetails.name}}</h1>
        //    <!--<input type="text" [value]="courseDetails.name"
        //    (input)="CalledOnChangeOftext($event)"  
        //    /> <br/>-->
        // <!--
        //     <input type="text" [(ngModel)]="courseDetails.name" /> -->
        //    <img src="{{courseDetails.imageUrl}}" height="200px"  /> 
        //    <img [src]="courseDetails.imageUrl" height="200px"  /> <br/>
        //    <b> Duration: </b> {{courseDetails.duration}} <br/>
        //    Is This course Free ? 
        //    <input type="checkbox" [(ngModel)]="courseDetails.isFree" />
        //     <div *ngIf="!courseDetails.isFree">
        //    <b> Price: </b> {{courseDetails.price}} 
        //    </div>
        //    <br/>
        //    <b> Trainer: </b> {{courseDetails.trainer}} <br/> 
        //    <input type="button" value="Is Success ?"
        //     [style.backgroundColor]="isSuccess ? 'green' : 'red' " 
        //     (click)="CalledOnClick()" />
        //    `    
    })
], CourseComponent);
exports.CourseComponent = CourseComponent;
//# sourceMappingURL=course.component.js.map